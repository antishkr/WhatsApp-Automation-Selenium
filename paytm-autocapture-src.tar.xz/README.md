# Paytm AutoCapture v0.3 — newest-first history scan (experimental)

This Android app uses an opt-in Notification Listener and Accessibility Service to record visible details from Paytm's **Balance & History > Payment History** UI. It does **not** read Paytm private databases, initiate payments, request PINs, or upload transaction details. No network permission is requested.

## Behavior

For **N incoming Paytm payment notifications**, after a brief four-and-a-half-second coalescing period the app opens Paytm using the newest active notification. When **Balance & History** is visible, it processes the **top N incoming (+₹) rows** newest-first. For each row it taps the row, waits for a separate transaction-detail screen, collects all accessible text, scrolls the detail screen where supported, stores an independent local record, goes back, and taps the next row. It scrolls the history list as needed. **Every position gets a separate record even if the amount or detail text is identical.** It flags unreadable or missing details rather than treating the history summary as a successful capture.

You may also tap **Capture top 5 / 10 / 30 history rows** to test a fixed number of the most recent visible history items. In manual mode, after tapping Start, open Paytm > Balance & History within 90 seconds. Keep the screen on and unlocked while processing. No auto-unlock.

## User-supplied UI reference

On the October 2026 Paytm screenshot, the Balance & History page has a Payment History section, and the first rows are incoming credits such as **+ ₹1** and **+ ₹2**, with payer, timestamp, and Money Transfer labels. The app uses Android accessibility element bounds to identify these amounts and click their rows. It never blindly taps a screen-coordinate template; when no credible row anchors exist, items require review.

## Important limits / validation

* This is a test build, **not an independently verified financial ledger**. UI navigation and text extraction must be validated on the actual target Android device. It may fail if Paytm exposes text as canvas content or its UI changes.
* Android background launch restrictions can block programmatic notification taps. If so, manually opening Balance & History permits manual scan testing.
* Native accessibility text extraction only. No screenshot OCR or notification-independent history reconciliation in this version.
* Queued events persist across app restarts. Active notification actions do not persist after Paytm removes them. Manual scans do not require notifications.
* Manual scans and notification-triggered scans use separate position queues. At most 30 rows per batch. If Paytm inserts new rows while scanning, row ordinals may shift; duplicates are preserved and cannot be used as the identity of a payment.
* When upgrading a debug build, Android may require uninstalling an older APK if signing certificates differ, which erases the app-local database. Export your CSV first.
* CSV exports are unencrypted at the user-selected storage destination.

## How to install and test

1. Install the debug APK and allow installation from this source when prompted.
2. Grant **Notification Access** and **Accessibility** access in Android Settings using the app buttons.
3. Enable **Start automatic capture**.
4. For a controlled test tap **Capture top 5 history rows**, then open Paytm > Balance & History and leave it visible. Wait while the app opens each row, reads details, returns, and advances.
5. Return to AutoCapture. You should have five separate rows: Captured or Review (not silently dropped). Inspect each item's expanded details and export CSV.
6. Test five real incoming payments only after the manual history test works. Then test 20–30 with the screen unlocked.

## Build/test

JDK 17, Android SDK API 35, Gradle 8.10.2: `gradle :app:testDebugUnitTest :app:assembleDebug`. GitHub Actions runs these commands and uploads `app-debug.apk`. Tests cover credit detection, identifying history vs details, previous/current page overlap, and identical entries as separate positions. Unit tests **cannot** certify Paytm UI interactions without access to a real phone.
