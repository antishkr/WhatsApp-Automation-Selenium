# Paytm AutoCapture (experimental Android build)

A user-controlled, offline Android utility for queuing **incoming** Paytm notifications, activating their saved notification actions (with an exact-notification accessibility click fallback) where Android permits, reading only visible Paytm UI text using an opt-in Accessibility Service, and exporting a CSV from app-private SQLite storage.

## Limitations / not a production payment ledger
- **No phone/Paytm integration testing has been performed remotely.** Test with real payment notifications on your own device before depending on it.
- Cannot read payments without notifications, recover dismissed notifications' PendingIntents, unlock phones, force background activity starts, or bypass secured text/screens.
- No OCR fallback in this version. If Paytm draws text inaccessible to Accessibility, records require manual review.
- On device reboot or process restart, queued metadata survives but actions can only be retrieved for **currently active** notifications.
- A queue entry must pass the screen detail and amount checks; no guessing for incorrect/unavailable screens. It deliberately queues events when screen off / locked and does not wake the device.
- Only the consumer Paytm package `net.one97.paytm` is monitored. The notification filter may need tuning to actual notification wording and language.
- **Do not rely on this tool as proof of settlement.** Match financial transactions against official Paytm/bank statements.

## Installation
1. Download the `app-debug.apk` from the successful GitHub Actions artifact, enable installation for your browser/files app, and install.
2. Open Paytm AutoCapture. Use the two buttons to grant Notification access and Accessibility service access explicitly.
3. Switch on automatic capture. Keep the phone **screen on and unlocked** while processing notifications.
4. Test receiving one small payment. On the dashboard check Capture / Review; inspect the captured raw screen text and amounts.
5. Test 5 notifications then 20–30, check that captured and flagged counts sum to the observed notification count, and export CSV.
6. Pausing stops opening Paytm but incoming notifications continue to be locally queued while the listener is connected. Export using Android's Save as document picker.

## Privacy
No INTERNET permission, cloud endpoint, login, analytics, root access, Paytm database access, UPI PIN access or transaction initiation. The database is private to the app; file-based encryption is provided by Android where supported, not a separate encrypted SQLite implementation. Exporting creates an unencrypted CSV at the destination you select. Android Accessibility access is powerful; disable it when not using the tool.

## Build
Requires JDK 17, Android SDK API 35 and Gradle 8.10.2. Run `gradle :app:testDebugUnitTest :app:assembleDebug`. The source includes a GitHub Actions pipeline producing an unsigned-for-release but installable, debug-signed APK artifact.
