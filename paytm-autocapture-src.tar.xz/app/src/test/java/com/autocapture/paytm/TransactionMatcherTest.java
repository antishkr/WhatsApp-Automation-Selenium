package com.autocapture.paytm;
import org.junit.Test;
import static org.junit.Assert.*;
public class TransactionMatcherTest {
  private static final String NOTIF="₹1,500 received from Rahul Sharma";
  private static final String SUMMARY="Payment Received ₹1,500 from Rahul Sharma Today";
  private static final String EXPANDED="Transaction Details\nPayment received successfully\n₹1,500\nReceived from Rahul Sharma\nDate and Time 15 Oct 10:35\nUPI Reference 123456789012\nPayment note: Order ABCD";
  @Test public void noSummaryCapture(){assertFalse(TransactionMatcher.expandedDetails(SUMMARY));assertFalse(TransactionMatcher.isVerifiedDetail(NOTIF,SUMMARY));}
  @Test public void detailRequiresMatch(){assertTrue(TransactionMatcher.isVerifiedDetail(NOTIF,EXPANDED));}
  @Test public void rejectWrongAmount(){assertFalse(TransactionMatcher.isVerifiedDetail("₹500 received from Rahul Sharma",EXPANDED));}
  @Test public void rejectWrongPayer(){assertFalse(TransactionMatcher.isVerifiedDetail("₹1500 received from Amit Kumar",EXPANDED));}
  @Test public void rejectMissingAmount(){assertFalse(TransactionMatcher.hasExactAmount("Payment Received",EXPANDED));}
  @Test public void rejectUnsafeButtons(){assertFalse(TransactionMatcher.safeRowText("₹500 - Send money"));assertTrue(TransactionMatcher.safeRowText("₹500 Received from Rahul Sharma"));}
  @Test public void detailAction(){assertTrue(TransactionMatcher.isDetailsAction("View Details"));assertFalse(TransactionMatcher.isDetailsAction("Pay Now"));}
  @Test public void extractPayer(){assertEquals("Rahul Sharma",TransactionMatcher.payer(NOTIF));}
  @Test public void refAndNote(){assertTrue(TransactionMatcher.containsReference(EXPANDED));}
}
