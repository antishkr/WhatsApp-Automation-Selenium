package com.autocapture.paytm;
import org.junit.Test;
import java.util.Arrays;
import static org.junit.Assert.*;
public class HistoryPlannerTest {
  @Test public void screenshotCredits(){assertTrue(HistoryPlanner.creditAnchor("+ ₹1"));assertTrue(HistoryPlanner.creditAnchor("+ ₹2"));assertFalse(HistoryPlanner.creditAnchor("- ₹300"));assertFalse(HistoryPlanner.creditAnchor("Check Balance"));}
  @Test public void distinguishPage(){assertTrue(HistoryPlanner.isHistory("Balance & History\nAccounts\nPayment History\n+ ₹1"));assertFalse(HistoryPlanner.isDetail("Balance & History\nAccounts\nPayment History\n+ ₹1"));assertTrue(HistoryPlanner.isDetail("Payment Received\n₹1\nReceived from Amit\nUPI Reference 123456789012"));}
  @Test public void preserveIdenticalTransactions(){assertEquals(2,HistoryPlanner.overlap(Arrays.asList("A","A","B"),Arrays.asList("A","B","C")));assertEquals(1,HistoryPlanner.shifted(Arrays.asList("A","A","A"),Arrays.asList("A","A","A")));}
  @Test public void scrolledHistoryWithoutHeader(){assertTrue(HistoryPlanner.isHistory("Rahul\nToday, 02:39 AM\nMoney Transfer\n+ ₹1\nPriya\nToday, 02:38 AM\nMoney Transfer\n+ ₹1"));}
  @Test public void newRowsAfterScroll(){assertEquals(2,HistoryPlanner.shifted(Arrays.asList("A","B","C"),Arrays.asList("C","D","E")));}
}
