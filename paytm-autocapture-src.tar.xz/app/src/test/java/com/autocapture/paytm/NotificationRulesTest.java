package com.autocapture.paytm;
import org.junit.Test;
import static org.junit.Assert.*;
public class NotificationRulesTest {
  @Test public void matchesIncoming(){assertTrue(NotificationRules.eligible("net.one97.paytm","Payment Received","₹1,500 received from Rahul"));}
  @Test public void rejectsOutgoing(){assertFalse(NotificationRules.eligible("net.one97.paytm","Payment sent","You paid ₹500 to Amit"));}
  @Test public void rejectsOtherApps(){assertFalse(NotificationRules.eligible("not.paytm","Payment Received","₹100 credited"));}
  @Test public void rejectsPromos(){assertFalse(NotificationRules.eligible("net.one97.paytm","Offers","Get ₹100 cashback on recharge"));}
  @Test public void parsesAmount(){assertEquals("1500.00",NotificationRules.amount("₹1,500.00 received"));}
  @Test public void validatesAmount(){assertTrue(NotificationRules.amountMatches("₹1,500 credited","₹1500.00 payment received"));assertFalse(NotificationRules.amountMatches("₹500 credited","₹200 received"));}
  @Test public void requiresDetail(){assertFalse(NotificationRules.looksLikeDetails("Your Paytm balance is ₹2000.00"));assertTrue(NotificationRules.looksLikeDetails("Payment received successfully! ₹500 from Rahul. UPI reference 123456789012"));}
  @Test public void extractsReference(){assertEquals("123456789012",NotificationRules.reference("UPI Reference No: 123456789012"));}
}
