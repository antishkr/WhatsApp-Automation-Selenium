package com.autocapture.paytm;

import java.math.BigDecimal;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Conservative, pure-Java matching rules. Never guesses that an unrelated payment is the target. */
public final class TransactionMatcher {
    private TransactionMatcher() {}
    private static final Pattern FROM = Pattern.compile("(?i)(?:received\\s+(?:money\\s+)?from|credited\\s+(?:by|from)|from|sent\\s+by)\\s+([\\p{L}][\\p{L} .'-]{1,55})");
    private static final Pattern REF = Pattern.compile("(?i)\\b(?:upi\\s*(?:ref(?:erence)?|transaction)\\s*(?:no\\.?|number|id)?|utr|transaction\\s*(?:id|no\\.?|number)|reference\\s*(?:id|no\\.?|number))\\b");
    private static final Pattern DETAIL = Pattern.compile("(?i)\\b(?:transaction details|payment details|transaction id|upi reference|upi ref|utr|reference no|reference number|view receipt|download receipt)\\b");
    private static final Pattern MORE = Pattern.compile("(?i)\\b(?:date|time|bank|remarks|remark|note|message|payment mode|status|received from|paid by|transaction)\\b");
    private static final Pattern ACTION = Pattern.compile("(?i)\\b(?:view details|transaction details|view transaction|see details|show details|more details|payment details|receipt)\\b");
    private static final Pattern DANGEROUS = Pattern.compile("(?i)\\b(?:pay now|send money|transfer money|add money|recharge now|pay bill|enter pin|upi pin|confirm payment|request money|refund|dispute|block|report fraud)\\b");

    public static String payer(String notification) {
        if(notification==null)return "";
        Matcher m=FROM.matcher(notification);
        if(!m.find())return "";
        String candidate=m.group(1).trim();
        candidate=candidate.replaceFirst("(?i)\\s+(?:on|via|using|at|for)\\b.*$","");
        candidate=candidate.replaceFirst("(?i)\\s+(?:rs\\.?|inr|₹)\\s*[\\d,]+.*$","");
        return candidate.trim();
    }
    public static boolean hasExactAmount(String notification,String screen){
        String a=NotificationRules.amount(notification),b=NotificationRules.amount(screen);
        if(a==null || b==null)return false;
        try{return new BigDecimal(a).compareTo(new BigDecimal(b))==0;}catch(NumberFormatException e){return false;}
    }
    /** Used only after the actual detail UI has been opened, or when notification directly lands on it. */
    public static boolean expandedDetails(String text){
        if(text==null || text.length()<45 || NotificationRules.amount(text)==null)return false;
        String lower=text.toLowerCase(Locale.ROOT);
        if(!(lower.contains("received")||lower.contains("credited")||lower.contains("success")||lower.contains("from")))return false;
        return (REF.matcher(text).find() && (lower.contains("transaction details") || lower.contains("payment details") || lower.contains("note") || lower.contains("remark") || lower.contains("bank"))) ||
            (DETAIL.matcher(text).find() && (lower.contains("note")||lower.contains("remark")));
    }
    public static boolean safeRowText(String text){
        if(text==null || text.length()<3 || text.length()>380)return false;
        return !DANGEROUS.matcher(text).find();
    }
    public static boolean isDetailsAction(String text){return text!=null && text.length()<100 && ACTION.matcher(text).find() && !DANGEROUS.matcher(text).find();}
    public static boolean payerMatches(String notification,String screen){
        String sender=payer(notification);
        if(sender.isEmpty())return true;
        String normalized=sender.toLowerCase(Locale.ROOT).replaceAll("\\s+"," ");
        // Require a meaningful name match, not just generic words such as 'from'.
        if(normalized.length()<3)return true;
        return screen.toLowerCase(Locale.ROOT).replaceAll("\\s+"," ").contains(normalized);
    }
    public static boolean isVerifiedDetail(String notification,String screen){
        return expandedDetails(screen) && hasExactAmount(notification,screen) && payerMatches(notification,screen);
    }
    public static boolean containsReference(String text){return text!=null && REF.matcher(text).find();}
}
