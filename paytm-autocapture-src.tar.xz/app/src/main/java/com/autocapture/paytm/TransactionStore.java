package com.autocapture.paytm;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/** App-private journal. No network connectivity; Android file-based encryption protects storage at rest. */
public final class TransactionStore extends SQLiteOpenHelper {
    public static final String PENDING="PENDING", PROCESSING="PROCESSING", RETRY="RETRY", CAPTURED="CAPTURED", REVIEW="REVIEW";
    public TransactionStore(Context c) { super(c,"payments.db",null,1); setWriteAheadLoggingEnabled(true); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT, nkey TEXT NOT NULL UNIQUE, posted INTEGER NOT NULL, title TEXT, body TEXT, state TEXT NOT NULL, tries INTEGER NOT NULL DEFAULT 0, updated INTEGER NOT NULL, captured INTEGER, detail TEXT, amount TEXT, reference TEXT, error TEXT)");
        db.execSQL("CREATE INDEX idx_state ON events(state,posted)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV) { throw new IllegalStateException("Migration required"); }
    public synchronized boolean enqueue(String key,long posted,String title,String body) {
        if (key==null) return false;
        ContentValues v=new ContentValues(); v.put("nkey",key);v.put("posted",posted);v.put("title",title);v.put("body",body);v.put("state",PENDING);v.put("updated",System.currentTimeMillis());
        return getWritableDatabase().insertWithOnConflict("events",null,v,SQLiteDatabase.CONFLICT_IGNORE)!=-1;
    }
    public synchronized void recover() { getWritableDatabase().execSQL("UPDATE events SET state='RETRY',error='Interrupted; resuming',updated=? WHERE state='PROCESSING'",new Object[]{System.currentTimeMillis()}); }
    public synchronized Event next() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,nkey,posted,title,body,state,tries,detail,error FROM events WHERE state IN ('PENDING','RETRY') AND tries<3 ORDER BY posted,id LIMIT 1",null)) { return c.moveToFirst()?read(c):null; }
    }
    public synchronized List<Event> latest(int max) {
        List<Event> a=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,nkey,posted,title,body,state,tries,detail,error FROM events ORDER BY posted DESC,id DESC LIMIT ?",new String[]{""+max})) {while(c.moveToNext())a.add(read(c));}
        return a;
    }
    private static Event read(Cursor c){return new Event(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3),c.getString(4),c.getString(5),c.getInt(6),c.getString(7),c.getString(8));}
    public synchronized void start(long id){getWritableDatabase().execSQL("UPDATE events SET state='PROCESSING',tries=tries+1,updated=?,error=NULL WHERE id=?",new Object[]{System.currentTimeMillis(),id});}
    public synchronized void issue(long id,String detail,String error,boolean retry) {
        ContentValues v=new ContentValues();v.put("state",retry?RETRY:REVIEW);v.put("updated",System.currentTimeMillis());v.put("error",error);if(detail!=null)v.put("detail",detail);getWritableDatabase().update("events",v,"id=?",new String[]{""+id});
    }
    public synchronized void captured(long id,String text){
        ContentValues v=new ContentValues();v.put("state",CAPTURED);v.put("updated",System.currentTimeMillis());v.put("captured",System.currentTimeMillis());v.put("detail",text);v.put("amount",NotificationRules.amount(text));v.put("reference",NotificationRules.reference(text));getWritableDatabase().update("events",v,"id=?",new String[]{""+id});
    }
    public synchronized void retryReview(){getWritableDatabase().execSQL("UPDATE events SET state='PENDING',tries=0,error=NULL WHERE state='REVIEW'");}
    public synchronized int count(String state){try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM events WHERE state=?",new String[]{state})){return c.moveToFirst()?c.getInt(0):0;}}
    public synchronized Cursor exportRows(){return getReadableDatabase().rawQuery("SELECT id,posted,title,body,state,tries,captured,amount,reference,detail,error FROM events ORDER BY posted,id",null);}
    public record Event(long id,String key,long posted,String title,String body,String state,int tries,String detail,String error) {}
}
