package com.autocapture.paytm;

import java.util.List;
import java.util.regex.Pattern;

/** Pure planning helpers for newest-first history traversal. No content deduplication. */
public final class HistoryPlanner {
    private HistoryPlanner() {}
    private static final Pattern CREDIT=Pattern.compile("(?i)(?:^|\\n)\\s*\\+\\s*(?:₹|rs\\.?|inr)\\s*[0-9][0-9,]*(?:\\.[0-9]{1,2})?\\b");
    public static boolean creditAnchor(String text) {
        return text != null && CREDIT.matcher(text.replace('\u00a0',' ')).find();
    }
    public static boolean isHistory(String text) {
        if(text==null)return false;
        String s=text.toLowerCase(java.util.Locale.ROOT);
        boolean title=s.contains("payment history") && (s.contains("balance & history") || s.contains("balance and history") || s.contains("accounts"));
        if(title)return true;
        // When the user scrolls, the sticky header can leave the accessibility viewport.
        // The repeated money-transfer row template still identifies the history list.
        return s.contains("money transfer") && CREDIT.matcher(text).find()
            && (s.contains("today")||s.contains("yesterday")||s.matches("(?s).*\\b\\d{1,2}\\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec).*"))
            && !s.contains("upi reference") && !s.contains("transaction id") && !s.contains("transaction details");
    }
    /** This is a separate screen, not the history list, and contains payment facts. */
    public static boolean isDetail(String text) {
        if(text==null||isHistory(text)||text.length()<22)return false;
        String s=text.toLowerCase(java.util.Locale.ROOT);
        boolean payment=s.contains("payment")||s.contains("transaction")||s.contains("money received")||s.contains("received from")||s.contains("upi")||s.contains("money transfer");
        boolean detail=s.contains("reference")||s.contains("transaction id")||s.contains("utr")||s.contains("note")||s.contains("remark")||s.contains("date")||s.contains("time")||s.contains("status")||s.contains("bank")||s.contains("received");
        return payment && detail && (text.contains("₹")||s.contains("rs.")||s.contains("inr"));
    }
    /** Largest previous suffix that is also a new prefix. Repeated identical rows are not deleted. */
    public static int overlap(List<String> previous, List<String> next){
        int max=Math.min(previous.size(),next.size());
        for(int count=max;count>0;count--){
            boolean same=true;
            for(int i=0;i<count;i++)if(!previous.get(previous.size()-count+i).equals(next.get(i))){same=false;break;}
            if(same)return count;
        }
        return 0;
    }
    /** Following a successful forward scroll, always advance at least one positional slot. */
    public static int shifted(List<String> previous,List<String> next){
        if(previous.isEmpty()||next.isEmpty())return 0;
        return Math.max(1,previous.size()-overlap(previous,next));
    }
}
