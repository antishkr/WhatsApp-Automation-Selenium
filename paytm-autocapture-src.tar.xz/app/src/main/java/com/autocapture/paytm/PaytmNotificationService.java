package com.autocapture.paytm;

import android.app.ActivityOptions;
import android.app.Notification;
import android.app.PendingIntent;
import android.os.Build;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

public final class PaytmNotificationService extends NotificationListenerService {
    private static volatile PaytmNotificationService active;
    @Override public void onListenerConnected(){ active=this; for(StatusBarNotification n:getActiveNotifications()) ingest(n); CaptureAccessibilityService.poke(); }
    @Override public void onListenerDisconnected(){active=null;}
    @Override public void onNotificationPosted(StatusBarNotification sbn){ingest(sbn);}
    private void ingest(StatusBarNotification sbn){
        if(sbn==null||!NotificationRules.PAYTM.equals(sbn.getPackageName()))return;
        Notification n=sbn.getNotification(); if(n==null || n.extras==null)return;
        CharSequence title=n.extras.getCharSequence(Notification.EXTRA_TITLE);CharSequence body=n.extras.getCharSequence(Notification.EXTRA_TEXT);
        String t=title==null?"":title.toString(), b=body==null?"":body.toString();
        if(!NotificationRules.eligible(sbn.getPackageName(),t,b))return;
        TransactionStore db=new TransactionStore(this);
        try { db.enqueue(sbn.getKey(),sbn.getPostTime(),t,b); }
        finally {db.close();}
        CaptureAccessibilityService.poke();
    }
    /** A notification's PendingIntent cannot be reconstructed after it disappears. */
    public static boolean activate(String key){
        PaytmNotificationService s=active;if(s==null)return false;
        try{
            StatusBarNotification[] items=s.getActiveNotifications(new String[]{key});
            if(items==null||items.length==0 || items[0]==null)return false;
            PendingIntent pi=items[0].getNotification().contentIntent;if(pi==null)return false;
            if(Build.VERSION.SDK_INT>=34){
                ActivityOptions o=ActivityOptions.makeBasic();
                o.setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED);
                pi.send(s,0,null,null,null,null,o.toBundle());
            } else pi.send();
            return true;
        }catch(PendingIntent.CanceledException|SecurityException e){ Log.w("AutoCapture","Notification action unavailable",e);return false; }
        catch(RuntimeException e){Log.w("AutoCapture","Unable to activate notification",e);return false;}
    }
    public static boolean isConnected(){return active!=null;}
    public static void rescan(){PaytmNotificationService s=active;if(s!=null)for(StatusBarNotification n:s.getActiveNotifications())s.ingest(n);}
}
