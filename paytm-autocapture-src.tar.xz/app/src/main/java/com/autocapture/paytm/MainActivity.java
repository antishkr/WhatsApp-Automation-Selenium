package com.autocapture.paytm;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;

/** Offline control panel; exports ONLY via user-chosen document provider. */
public final class MainActivity extends Activity {
    private static final int EXPORT_CSV=300;
    private TransactionStore db;
    private LinearLayout screen,entries;
    private TextView state,counts,info;
    private Button toggle;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable refreshTask=new Runnable(){@Override public void run(){refresh();handler.postDelayed(this,2500);}};
    @Override public void onCreate(Bundle b){super.onCreate(b);db=new TransactionStore(this);render();}
    @Override protected void onResume(){super.onResume();handler.removeCallbacks(refreshTask);handler.post(refreshTask);}
    @Override protected void onPause(){handler.removeCallbacks(refreshTask);super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacks(refreshTask);db.close();super.onDestroy();}
    private int dp(int d){return (int)(d*getResources().getDisplayMetrics().density+0.5f);}
    private TextView label(String s,int sp,int color){TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(sp);v.setPadding(0,dp(6),0,dp(6));return v;}
    private Button button(String title,Runnable run){Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setOnClickListener(v->run.run());return b;}
    private void render(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);setContentView(scroll);
        screen=new LinearLayout(this);screen.setPadding(dp(20),dp(22),dp(20),dp(40));screen.setOrientation(LinearLayout.VERTICAL);screen.setBackgroundColor(Color.rgb(248,249,252));scroll.addView(screen);
        screen.addView(label("Paytm AutoCapture",25,Color.rgb(19,29,47)));
        screen.addView(label("Private, on-device transaction text capture • experimental build",13,Color.DKGRAY));
        state=label("Checking permissions...",14,Color.rgb(45,75,130));screen.addView(state);
        counts=label("",19,Color.rgb(19,29,47));screen.addView(counts);
        toggle=button("Start automatic capture",()->{
            boolean isOn=getSharedPreferences("settings",MODE_PRIVATE).getBoolean("enabled",false);
            getSharedPreferences("settings",MODE_PRIVATE).edit().putBoolean("enabled",!isOn).apply();CaptureAccessibilityService.poke();refresh();
        });screen.addView(toggle);
        screen.addView(button("1. Enable notification access",()->startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))));
        screen.addView(button("2. Enable accessibility service",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        screen.addView(button("Rescan active Paytm notifications",()->{PaytmNotificationService.rescan();CaptureAccessibilityService.poke();refresh();toast("Active notifications checked");}));
        screen.addView(button("Retry items needing review",()->new AlertDialog.Builder(this).setTitle("Retry flagged transactions?").setMessage("Only notifications that still have a usable Paytm action can be retried. Others may need manual reconciliation.").setNegativeButton("Cancel",null).setPositiveButton("Retry",(d,w)->{db.retryReview();CaptureAccessibilityService.poke();refresh();}).show()));
        screen.addView(button("Export ALL records to CSV",()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/csv").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"paytm-transactions.csv");startActivityForResult(i,EXPORT_CSV);}));
        info=label("",12,Color.DKGRAY);screen.addView(info);
        screen.addView(label("Recent transactions — tap to inspect",17,Color.rgb(19,29,47)));
        entries=new LinearLayout(this);entries.setOrientation(LinearLayout.VERTICAL);screen.addView(entries);
        screen.addView(label("Does not initiate payments, read UPI PINs, access Paytm private databases or transmit data online. Locked/screen-off phones are queued; Android may reject background notification opens.",12,Color.DKGRAY));
    }
    private void refresh(){if(state==null)return;
        boolean notif=PaytmNotificationService.isConnected(),access=CaptureAccessibilityService.isConnected(),enabled=getSharedPreferences("settings",MODE_PRIVATE).getBoolean("enabled",false);
        toggle.setText(enabled?"Pause automation":"Start automatic capture");
        state.setText("Notification access: "+(notif?"ON":"OFF")+"  •  Screen reader: "+(access?"ON":"OFF")+"\nAutomation: "+(enabled?"ENABLED":"PAUSED"));
        counts.setText(db.count(TransactionStore.CAPTURED)+" captured   •   "+(db.count(TransactionStore.PENDING)+db.count(TransactionStore.RETRY)+db.count(TransactionStore.PROCESSING))+" queued   •   "+db.count(TransactionStore.REVIEW)+" review");
        info.setText("Keep the phone screen on and unlocked during capture. Open this app first to set permissions. Results depend on Paytm's actual notification and accessibility behavior.");
        entries.removeAllViews();List<TransactionStore.Event> list=db.latest(50);
        if(list.isEmpty())entries.addView(label("No events detected yet. Only incoming-payment notifications are queued.",13,Color.GRAY));
        DateFormat date=DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT);
        for(TransactionStore.Event e:list){
            TextView row=label("● "+e.state+"   "+date.format(new Date(e.posted))+"\n"+s(e.title)+" — "+s(e.body),14,Color.rgb(23,40,65));
            row.setPadding(dp(10),dp(8),dp(10),dp(8));row.setBackgroundTintList(ColorStateList.valueOf(Color.WHITE));
            row.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Transaction #"+e.id+" — "+e.state)
              .setMessage("NOTIFICATION\n"+s(e.title)+"\n"+s(e.body)+"\n\nSCREEN TEXT\n"+(TextUtils.isEmpty(e.detail)?"Not captured":e.detail)+"\n\nERROR\n"+s(e.error))
              .setPositiveButton("Close",null).show());entries.addView(row);
            View gap=new View(this);entries.addView(gap,new LinearLayout.LayoutParams(1,dp(6)));
        }
    }
    private static String s(String s){return s==null?"":s;}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==EXPORT_CSV && result==RESULT_OK && data!=null){Uri uri=data.getData();if(uri!=null)export(uri);}}
    private void export(Uri uri){
        try(OutputStream os=getContentResolver().openOutputStream(uri,"w");Cursor c=db.exportRows()){
            if(os==null)throw new IllegalStateException("Cannot open destination");
            os.write("id,notification_posted_ms,title,body,status,attempts,captured_at_ms,amount,upi_reference,raw_screen_text,error\r\n".getBytes(StandardCharsets.UTF_8));
            while(c.moveToNext()){
                StringBuilder b=new StringBuilder();for(int i=0;i<c.getColumnCount();i++){if(i>0)b.append(',');b.append(csv(c.getString(i)));}b.append("\r\n");os.write(b.toString().getBytes(StandardCharsets.UTF_8));
            }os.flush();toast("CSV exported");
        }catch(Exception ex){new AlertDialog.Builder(this).setTitle("Export failed").setMessage(ex.getMessage()).setPositiveButton("OK",null).show();}
    }
    static String csv(String text){if(text==null)return "\"\"";return "\""+text.replace("\"","\"\"")+"\"";}
}
