package com.autocapture.paytm;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Deterministic, conservative filtering; never infer that money arrived from amount alone. */
public final class NotificationRules {
    private NotificationRules() {}
    public static final String PAYTM = "net.one97.paytm";
    private static final Pattern MONEY = Pattern.compile("(?:₹|rs\\.?|inr)\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern RECEIVE = Pattern.compile("(?i)\\b(received|credited|money added|money received|payment received|you got|sent you|has paid|paid you)\\b");
    private static final Pattern OUTGOING = Pattern.compile("(?i)\\b(you paid|paid to|sent to|payment sent|debited)\\b");
    public static boolean eligible(String pkg, String title, String body) {
        if (!PAYTM.equals(pkg)) return false;
        String t = ((title == null ? "" : title) + " " + (body == null ? "" : body)).toLowerCase(Locale.ROOT);
        return RECEIVE.matcher(t).find() && !OUTGOING.matcher(t).find();
    }
    public static String amount(String s) {
        if (s == null) return null;
        Matcher m = MONEY.matcher(s);
        if (!m.find()) return null;
        return m.group(1).replace(",", "");
    }
    public static boolean amountMatches(String notification, String screen) {
        String a = amount(notification), b = amount(screen);
        if (a == null || b == null) return true; // do not silently assert an amount was validated
        try { return new java.math.BigDecimal(a).compareTo(new java.math.BigDecimal(b)) == 0; }
        catch (NumberFormatException e) { return false; }
    }
    public static boolean looksLikeDetails(String text) {
        if (text == null || text.length() < 35 || amount(text) == null) return false;
        String s = text.toLowerCase(Locale.ROOT);
        boolean detail = s.contains("transaction") || s.contains("reference") || s.contains("upi ref") || s.contains("utr") || s.contains("payment details") || s.contains("payment received");
        boolean receipt = s.contains("received") || s.contains("credited") || s.contains("from") || s.contains("successful") || s.contains("success");
        return detail && receipt;
    }
    public static String reference(String s) {
        if (s == null) return "";
        Matcher m = Pattern.compile("(?i)(?:upi ref(?:erence)?(?: no\\.?)?|utr|transaction id|reference (?:no\\.?|id))\\s*[:#-]?\\s*([0-9]{10,20})").matcher(s.replace('\n',' '));
        return m.find() ? m.group(1) : "";
    }
}
