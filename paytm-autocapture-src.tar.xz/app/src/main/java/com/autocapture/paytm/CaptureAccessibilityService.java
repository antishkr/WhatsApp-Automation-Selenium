package com.autocapture.paytm;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.KeyguardManager;
import android.content.Context;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

/**
 * Newest-first, read-only Paytm history capture. One UI row maps to one database row,
 * regardless of duplicate amounts, payers, or captured text.
 * Works only while unlocked, after user explicitly grants Accessibility access.
 */
public final class CaptureAccessibilityService extends AccessibilityService {
    private static final String PAYTM=NotificationRules.PAYTM;
    private static final int WAIT_HISTORY=1, WAIT_DETAILS=2, READ_DETAILS=3, GO_BACK=4, WAIT_SCROLL=5;
    private static volatile CaptureAccessibilityService instance;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable loop=new Runnable(){@Override public void run(){tick();handler.postDelayed(this,950);}};
    private TransactionStore db;
    private List<TransactionStore.Event> batch=Collections.emptyList();
    private int phase=0,index=0,offset=0,detailStable=0,detailScrolls=0,scrollAttempts=0;
    private long phaseAt=0,batchAt=0,detailLastScroll=0,scanId=0,lastNavigation=0;
    private boolean manuallyStarted=false;
    private String detailSnapshot="",diagnostic="";
    private final LinkedHashSet<String> detailLines=new LinkedHashSet<>();
    private List<HistoryRow> beforeScroll=new ArrayList<>();
    private boolean launchAttempted=false;

    @Override protected void onServiceConnected(){super.onServiceConnected();instance=this;db=new TransactionStore(this);db.recover();handler.removeCallbacks(loop);handler.post(loop);}
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* Polling debounces Paytm WebView redraws. */ }
    @Override public void onInterrupt() {}
    @Override public void onDestroy(){handler.removeCallbacks(loop);instance=null;if(db!=null)db.close();super.onDestroy();}
    public static boolean isConnected(){return instance!=null;}
    public static String progress(){
        CaptureAccessibilityService s=instance;
        return s==null?"Screen reader disconnected":s.batch.isEmpty()?"Waiting for notifications or manual scan":
            "History capture: row "+(s.index+1)+" of "+s.batch.size()+" • "+
            (s.phase==WAIT_HISTORY?"waiting for Balance & History":s.phase==WAIT_DETAILS?"opening detail":s.phase==READ_DETAILS?"reading detail":s.phase==WAIT_SCROLL?"scrolling":"returning to history");
    }
    public static void poke(){CaptureAccessibilityService s=instance;if(s!=null)s.handler.post(s::tick);}

    private boolean allowed(){
        if(!getSharedPreferences("settings",MODE_PRIVATE).getBoolean("enabled",false))return false;
        KeyguardManager keyguard=(KeyguardManager)getSystemService(Context.KEYGUARD_SERVICE);
        PowerManager power=(PowerManager)getSystemService(Context.POWER_SERVICE);
        return keyguard!=null && !keyguard.isDeviceLocked() && power!=null && power.isInteractive();
    }
    private void startBatch(long now){
        List<TransactionStore.Event> pending=db.nextBatch(30);
        if(pending.isEmpty())return;
        // Coalesce payment notifications into one top-N history traversal.
        if(!pending.get(0).key().startsWith("manual/") && now-db.newestPendingTime()<4500)return;
        batch=pending;index=0;offset=0;scrollAttempts=0;beforeScroll.clear();
        scanId=now;batchAt=now;phaseAt=now;phase=WAIT_HISTORY;
        manuallyStarted=batch.get(0).key().startsWith("manual/");launchAttempted=false;
        if(!manuallyStarted)activateFirst();
    }
    private void activateFirst(){
        if(batch.isEmpty()||launchAttempted)return;
        launchAttempted=true;
        // The observed Paytm notification lands in History. Other versions may require
        // opening Balance & History from the resulting Paytm page.
        PaytmNotificationService.activate(batch.get(0).key());
    }
    private void setPhase(int newPhase,long now){phase=newPhase;phaseAt=now;}
    private void reset(){batch=Collections.emptyList();index=0;offset=0;phase=0;beforeScroll.clear();detailLines.clear();}
    private void reviewRemaining(String error){
        for(int i=index;i<batch.size();i++)db.issue(batch.get(i).id(),null,error,false);
        reset();
    }
    private void failRow(String error,long now){
        if(index<batch.size())db.issue(batch.get(index).id(),diagnostic,error,false);
        index++;
        if(index>=batch.size()) { // Return to history for privacy even if the last row fails.
            performGlobalAction(GLOBAL_ACTION_BACK);reset();return;
        }
        performGlobalAction(GLOBAL_ACTION_BACK);
        setPhase(GO_BACK,now);
    }
    private void saveRow(long now){
        if(index>=batch.size()){reset();return;}
        String all=String.join("\n",detailLines);
        // Do not save the history summary; every captured row must have been tapped
        // and changed into a separate transaction-detail screen.
        if(!HistoryPlanner.isDetail(all)){
            failRow("Tapped row but expanded details not proven. Preview: "+shorten(all,160),now);return;
        }
        db.captured(batch.get(index).id(),all);
        index++;
        detailLines.clear();
        performGlobalAction(GLOBAL_ACTION_BACK);
        if(index>=batch.size())reset();else setPhase(GO_BACK,now);
    }
    private void tick(){
        if(db==null||!allowed())return;
        long now=System.currentTimeMillis();
        if(batch.isEmpty()){startBatch(now);return;}
        AccessibilityNodeInfo root=getRootInActiveWindow();
        String page="";
        if(root!=null && root.getPackageName()!=null && PAYTM.contentEquals(root.getPackageName()))page=read(root);
        boolean history=HistoryPlanner.isHistory(page);
        if(phase==WAIT_HISTORY){
            if(history){setPhase(GO_BACK,now);return;}
            if(now-phaseAt<1700)return;
            if(!page.isEmpty() && now-lastNavigation>1900){
                AccessibilityNodeInfo historyLink=findHistoryLink(root);
                if(historyLink!=null && clickSafe(historyLink)){
                    lastNavigation=now;phaseAt=now;return;
                }
            }
            if(now-batchAt>(manuallyStarted?90000:25000))reviewRemaining("Balance & History not reachable. Open Paytm > Balance & History and retry. Only visible UI can be read.");
            return;
        }
        if(phase==GO_BACK){
            if(history){
                if(now-phaseAt<850)return;
                chooseRow(root,now);return;
            }
            if(now-phaseAt>11500){reviewRemaining("Could not return to the payment history list");return;}
            if(now-phaseAt>3500 && now-lastNavigation>2000){
                performGlobalAction(GLOBAL_ACTION_BACK);lastNavigation=now;
            }
            return;
        }
        if(phase==WAIT_SCROLL){
            if(!history){if(now-phaseAt>13000)reviewRemaining("History disappeared during scrolling");return;}
            if(now-phaseAt<1000)return;
            List<HistoryRow> newRows=findRows(root);
            if(newRows.isEmpty()){
                if(now-phaseAt>9000)reviewRemaining("Scrolled history but no incoming rows were accessible");return;
            }
            int moved=HistoryPlanner.shifted(signatures(beforeScroll),signatures(newRows));
            if(moved==0){
                if(now-phaseAt>4000)reviewRemaining("Unable to locate the next history row after scrolling");return;
            }
            offset+=moved;
            if(offset>index)offset=index; // Do not skip an unprocessed ordinal.
            beforeScroll.clear();setPhase(GO_BACK,now-900);return;
        }
        if(phase==WAIT_DETAILS){
            if(!page.isEmpty() && !history && HistoryPlanner.isDetail(page)){
                detailLines.clear();detailSnapshot="";detailStable=0;detailScrolls=0;detailLastScroll=0;
                setPhase(READ_DETAILS,now);return;
            }
            if(now-phaseAt>14000){
                diagnostic=page;
                failRow("Transaction was tapped, but the expanded details screen did not appear or expose text",now);
            }
            return;
        }
        if(phase==READ_DETAILS){
            if(page.isEmpty()){if(now-phaseAt>9000)failRow("Paytm detail text became unavailable",now);return;}
            if(history){failRow("Unexpectedly returned to history before reading details",now);return;}
            if(!HistoryPlanner.isDetail(page)){
                if(now-phaseAt>6500)failRow("Expanded details were not readable",now);return;
            }
            for(String line:page.split("\\n")){String part=line.trim();if(!part.isEmpty())detailLines.add(part);}
            if(page.equals(detailSnapshot))detailStable++;else{detailSnapshot=page;detailStable=0;}
            if(detailStable<2||now-phaseAt<1500||now-detailLastScroll<1500)return;
            AccessibilityNodeInfo scroller=findScroller(root,0,new int[]{0});
            if(scroller!=null && detailScrolls<4 && scroller.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)){
                detailScrolls++;detailLastScroll=now;detailStable=0;return;
            }
            saveRow(now);
        }
    }
    private void chooseRow(AccessibilityNodeInfo root,long now){
        if(index>=batch.size()){reset();return;}
        List<HistoryRow> rows=findRows(root);
        if(rows.isEmpty()){
            if(now-phaseAt>8500)reviewRemaining("Found Payment History but its credit rows are not accessibility-readable");
            return;
        }
        int local=index-offset;
        if(local>=rows.size()){
            if(scrollAttempts++>=35){reviewRemaining("Reached history navigation limit before all rows were captured");return;}
            beforeScroll=rows;
            if(!scrollHistory(root,rows)){
                reviewRemaining("Unable to scroll Paytm history to the next transaction");return;
            }
            setPhase(WAIT_SCROLL,now);return;
        }
        if(local<0){reviewRemaining("Lost scan position after Paytm refreshed history");return;}
        HistoryRow row=rows.get(local);
        db.start(batch.get(index).id(),index+1,scanId);
        diagnostic="";
        if(!tapHistoryRow(row)){
            db.issue(batch.get(index).id(),null,"Could not tap history row "+(index+1),false);
            index++;setPhase(GO_BACK,now);return;
        }
        setPhase(WAIT_DETAILS,now);
    }
    private static String shorten(String s,int size){return s==null?"":s.length()>size?s.substring(0,size):s;}

    private static final class TextAnchor {
        final String text;final Rect rect;
        TextAnchor(String text,Rect rect){this.text=text;this.rect=rect;}
    }
    private static final class HistoryRow {
        final Rect amountRect;final AccessibilityNodeInfo node;final String signature;
        HistoryRow(Rect r,AccessibilityNodeInfo n,String signature){amountRect=r;node=n;this.signature=signature;}
    }
    private List<HistoryRow> findRows(AccessibilityNodeInfo root){
        List<TextAnchor> texts=new ArrayList<>();List<AccessibilityNodeInfo> credits=new ArrayList<>();
        gather(root,texts,credits,0,new int[]{0});
        int headerY=0;for(TextAnchor a:texts){if(a.text.toLowerCase(Locale.ROOT).contains("payment history") && !a.text.toLowerCase(Locale.ROOT).contains("balance"))headerY=Math.max(headerY,a.rect.bottom);}
        List<HistoryRow> rows=new ArrayList<>();
        int width=getResources().getDisplayMetrics().widthPixels;
        for(AccessibilityNodeInfo n:credits){
            Rect r=new Rect();n.getBoundsInScreen(r);
            if(r.isEmpty()||r.centerY()<=headerY+dp(20)||r.centerX()<=width/2)continue;
            boolean nearby=false;
            for(HistoryRow old:rows)if(Math.abs(old.amountRect.centerY()-r.centerY())<dp(45)){nearby=true;break;}
            if(nearby)continue;
            List<String> words=new ArrayList<>();
            for(TextAnchor a:texts){if(Math.abs(a.rect.centerY()-r.centerY())<dp(65) && a.text.length()<100)words.add(a.text.toLowerCase(Locale.ROOT).trim());}
            Collections.sort(words);
            String signature=String.join("|",words);
            rows.add(new HistoryRow(r,n,signature));
        }
        rows.sort(Comparator.comparingInt(o->o.amountRect.centerY()));
        return rows;
    }
    private void gather(AccessibilityNodeInfo n,List<TextAnchor> texts,List<AccessibilityNodeInfo> credits,int depth,int[] seen){
        if(n==null||depth>45||seen[0]++>850)return;
        try{
            if(n.isVisibleToUser()){
                String value=n.getText()==null?"":n.getText().toString().trim();
                if(value.isEmpty() && n.getContentDescription()!=null)value=n.getContentDescription().toString().trim();
                if(!value.isEmpty()){
                    Rect rect=new Rect();n.getBoundsInScreen(rect);
                    if(!rect.isEmpty()){
                        texts.add(new TextAnchor(value,rect));
                        if(value.length()<100 && rect.height()<dp(145) && HistoryPlanner.creditAnchor(value))credits.add(n);
                    }
                }
            }
            for(int i=0;i<Math.min(90,n.getChildCount());i++)gather(n.getChild(i),texts,credits,depth+1,seen);
        }catch(IllegalStateException ignored){}
    }
    private static List<String> signatures(List<HistoryRow> rows){
        List<String> s=new ArrayList<>();for(HistoryRow row:rows)s.add(row.signature);return s;
    }
    private boolean tapHistoryRow(HistoryRow r){
        AccessibilityNodeInfo n=r.node;
        for(int i=0;n!=null && i<6;i++,n=n.getParent()){
            Rect rect=new Rect();n.getBoundsInScreen(rect);
            if(n.isClickable()&&n.isVisibleToUser() && rect.height()>=dp(30) && rect.height()<dp(310)){
                try{if(n.performAction(AccessibilityNodeInfo.ACTION_CLICK))return true;}catch(IllegalStateException ignored){}
            }
        }
        // Coordinate fallback is tied to the actual +₹ amount accessibility bounds;
        // never tap fixed screen positions or a guessed payment button.
        int screenWidth=getResources().getDisplayMetrics().widthPixels;
        return tapAt((int)(screenWidth*0.52f),r.amountRect.centerY());
    }
    private boolean scrollHistory(AccessibilityNodeInfo root,List<HistoryRow> rows){
        AccessibilityNodeInfo scrollable=findScroller(root,0,new int[]{0});
        if(scrollable!=null && scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD))return true;
        int width=getResources().getDisplayMetrics().widthPixels;
        int height=getResources().getDisplayMetrics().heightPixels;
        int start=Math.min(height-dp(125),rows.get(rows.size()-1).amountRect.centerY()+dp(65));
        int stop=Math.max(dp(200),start-(int)(height*0.34f));
        return swipe(width/2,start,width/2,stop);
    }
    private boolean tapAt(int x,int y){
        Path p=new Path();p.moveTo(x,y);
        GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,95)).build();
        return dispatchGesture(g,null,null);
    }
    private boolean swipe(int x1,int y1,int x2,int y2){
        if(y1<=y2)return false;
        Path p=new Path();p.moveTo(x1,y1);p.lineTo(x2,y2);
        GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,420)).build();
        return dispatchGesture(g,null,null);
    }
    private AccessibilityNodeInfo findHistoryLink(AccessibilityNodeInfo node){
        if(node==null)return null;
        try{
            String s=node.getText()!=null?node.getText().toString():"";
            if(s.matches("(?is).*\\bbalance\\s*(?:&|and)\\s*history\\b.*") && s.length()<80){
                for(AccessibilityNodeInfo parent=node,cur=parent;cur!=null;cur=cur.getParent()){
                    if(cur.isClickable() && cur.isVisibleToUser())return cur;
                }
            }
            for(int i=0;i<Math.min(60,node.getChildCount());i++){
                AccessibilityNodeInfo x=findHistoryLink(node.getChild(i));if(x!=null)return x;
            }
        }catch(IllegalStateException ignored){}
        return null;
    }
    private boolean clickSafe(AccessibilityNodeInfo n){
        Rect r=new Rect();n.getBoundsInScreen(r);
        return !r.isEmpty()&&r.height()<dp(300)&&n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }
    private AccessibilityNodeInfo findScroller(AccessibilityNodeInfo n,int depth,int[] count){
        if(n==null||depth>36||count[0]++>400)return null;
        try{
            for(int i=0;i<Math.min(65,n.getChildCount());i++){
                AccessibilityNodeInfo child=findScroller(n.getChild(i),depth+1,count);if(child!=null)return child;
            }
            if(n.isScrollable()&&n.isVisibleToUser()&&(n.getActions()&AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)!=0)return n;
        }catch(IllegalStateException ignored){}
        return null;
    }
    private String read(AccessibilityNodeInfo root){
        LinkedHashSet<String> a=new LinkedHashSet<>();scan(root,a,0,new int[]{0});return String.join("\n",a);
    }
    private void scan(AccessibilityNodeInfo node,LinkedHashSet<String> out,int depth,int[] seen){
        if(node==null||depth>45||seen[0]++>850)return;
        try{
            if(node.isVisibleToUser()){
                if(node.getText()!=null){String t=node.getText().toString().trim();if(!t.isEmpty())out.add(t);}
                if(node.getContentDescription()!=null){String t=node.getContentDescription().toString().trim();if(!t.isEmpty())out.add(t);}
            }
            for(int i=0;i<Math.min(80,node.getChildCount());i++)scan(node.getChild(i),out,depth+1,seen);
        }catch(IllegalStateException ignored){}
    }
    private int dp(int p){return (int)(getResources().getDisplayMetrics().density*p+0.5f);}
}
