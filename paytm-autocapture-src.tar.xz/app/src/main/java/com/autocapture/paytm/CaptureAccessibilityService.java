package com.autocapture.paytm;

import android.accessibilityservice.AccessibilityService;
import android.app.KeyguardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.LinkedHashSet;
import java.util.List;

/** Single-transaction state machine: no blind coordinates, no clicking buttons inside Paytm. */
public final class CaptureAccessibilityService extends AccessibilityService {
    private static volatile CaptureAccessibilityService instance;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private TransactionStore db;
    private TransactionStore.Event current;
    private long started;
    private boolean usingShade=false;
    private String previousScreen="";
    private String lastCapturedScreen="";
    private String candidate="";
    private int stableCount=0;
    private final Runnable tickTask=new Runnable(){@Override public void run(){ tick();handler.postDelayed(this,1100); }};

    @Override protected void onServiceConnected(){super.onServiceConnected();instance=this;db=new TransactionStore(this);db.recover();handler.removeCallbacks(tickTask);handler.post(tickTask);}
    @Override public void onAccessibilityEvent(AccessibilityEvent event){if(current!=null && event!=null){/* main loop observes settled screen */}}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){instance=null;handler.removeCallbacks(tickTask);if(db!=null)db.close();super.onDestroy();}
    public static void poke(){CaptureAccessibilityService s=instance;if(s!=null)s.handler.post(s::tick);}
    public static boolean isConnected(){return instance!=null;}
    private boolean canRun(){
        if(!getSharedPreferences("settings",MODE_PRIVATE).getBoolean("enabled",false))return false;
        KeyguardManager keyguard=(KeyguardManager)getSystemService(Context.KEYGUARD_SERVICE);
        PowerManager power=(PowerManager)getSystemService(Context.POWER_SERVICE);
        return keyguard!=null && !keyguard.isDeviceLocked() && power!=null && power.isInteractive();
    }
    private void tick(){
        if(db==null)return;
        if(!canRun())return;  // no lock-screen bypass or waking phone
        if(current==null){
            if(!PaytmNotificationService.isConnected())return;
            TransactionStore.Event next=db.next();if(next==null)return;
            current=next;started=System.currentTimeMillis();usingShade=false;stableCount=0;candidate="";
            previousScreen=readPaytmScreen();
            db.start(current.id);
            if(!PaytmNotificationService.activate(current.key)) {
                // Foreground-compatible fallback: open notifications and click exactly one matching row.
                usingShade=performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
                if(!usingShade){db.issue(current.id,null,"No active notification action; notification shade unavailable",false);current=null;}
            }
            return;
        }
        long elapsed=System.currentTimeMillis()-started;
        if(usingShade){
            if(elapsed>7000){db.issue(current.id,null,"Could not identify a unique Paytm notification in shade",false);current=null;return;}
            if(elapsed<850)return;
            AccessibilityNodeInfo root=getRootInActiveWindow();
            if(root==null || root.getPackageName()==null || !root.getPackageName().toString().contains("systemui"))return;
            int matches=clickUniqueNotification(root,current);
            if(matches==1){usingShade=false;started=System.currentTimeMillis();}
            else if(matches>1){db.issue(current.id,null,"Ambiguous notification shade match — no click performed",false);current=null;}
            return;
        }
        if(elapsed>22000){
            boolean retry=current.tries+1<3;
            db.issue(current.id,candidate,"Timed out waiting for verifiable transaction details",retry);
            current=null;return;
        }
        if(elapsed<2000)return; // Paytm UI often briefly displays the PREVIOUS payment
        String text=readPaytmScreen();
        if(text.isEmpty())return;
        if(text.equals(previousScreen) || text.equals(lastCapturedScreen))return; // reject stale screen
        if(!NotificationRules.looksLikeDetails(text))return;
        String notificationText=(current.title==null?"":current.title)+" "+(current.body==null?"":current.body);
        if(!NotificationRules.amountMatches(notificationText,text))return;
        if(text.equals(candidate))stableCount++; else {candidate=text;stableCount=1;}
        if(stableCount>=2){
            db.captured(current.id,text);lastCapturedScreen=text;current=null;stableCount=0;
        }
    }
    /** Click only one row with an exact notification body, NEVER coordinates or payment controls. */
    private int clickUniqueNotification(AccessibilityNodeInfo root,TransactionStore.Event e){
        String body=e.body==null?"":e.body.trim();
        if(body.length()<7)return 2; // cannot safely identify generic notification titles
        java.util.ArrayList<AccessibilityNodeInfo> matches=new java.util.ArrayList<>();
        findClickableRows(root,body,matches,0,new int[]{0});
        if(matches.size()!=1)return matches.size();
        try{return matches.get(0).performAction(AccessibilityNodeInfo.ACTION_CLICK)?1:0;}
        catch(Exception ex){return 0;}
    }
    private void findClickableRows(AccessibilityNodeInfo n,String text,java.util.List<AccessibilityNodeInfo> list,int depth,int[] seen){
        if(n==null||depth>35||seen[0]++>350)return;
        try{
            if(n.isClickable() && n.isVisibleToUser()){
                LinkedHashSet<String> labels=new LinkedHashSet<>();scan(n,labels,0,new int[]{0});
                // Exact lines limit wrong taps when amounts/senders overlap.
                if(labels.contains(text) && labels.size()<=15){list.add(n);return;}
            }
            for(int i=0;i<Math.min(n.getChildCount(),50);i++)findClickableRows(n.getChild(i),text,list,depth+1,seen);
        }catch(IllegalStateException ignored){}
    }
    private String readPaytmScreen(){
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null||root.getPackageName()==null||!NotificationRules.PAYTM.contentEquals(root.getPackageName()))return "";
        LinkedHashSet<String> lines=new LinkedHashSet<>();scan(root,lines,0,new int[]{0});
        return String.join("\n",lines);
    }
    private void scan(AccessibilityNodeInfo n,LinkedHashSet<String> lines,int depth,int[] seen){
        if(n==null||depth>45||seen[0]++>650)return;
        try{
            CharSequence t=n.getText(), d=n.getContentDescription();
            if(t!=null){String s=t.toString().trim();if(!s.isEmpty())lines.add(s);}
            if(d!=null){String s=d.toString().trim();if(!s.isEmpty()&&!s.equals(t==null?"":t.toString()))lines.add(s);}
            int count=Math.min(n.getChildCount(),100);
            for(int i=0;i<count;i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)scan(c,lines,depth+1,seen);}
        }catch(IllegalStateException ignored) { /* view recycled mid-frame */ }
    }
}
